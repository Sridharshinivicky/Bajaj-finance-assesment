import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import queryString from 'query-string';
import DoctorPage from './DoctorPage';

function App() {
  const navigate = useNavigate();
  const { search, pathname } = useLocation();
  const qs = queryString.parse(search);

  const [allDoctors, setAllDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchText, setSearchText] = useState(qs.name || '');
  const [consultType, setConsultType] = useState(qs.type || '');
  const [specialties, setSpecialties] = useState(qs.specs ? qs.specs.split(',') : []);
  const [sortBy, setSortBy] = useState(qs.sort || '');

  // Fetch data
  useEffect(() => {
    fetch('https://srijandubey.github.io/campus-api-mock/SRM-C1-25.json')
      .then(r => r.json())
      .then(data => {
        setAllDoctors(data.doctors || []);
        setLoading(false);
      });
  }, []);

  // Sync URL
  useEffect(() => {
    const params = {};
    if (searchText) params.name = searchText;
    if (consultType) params.type = consultType;
    if (specialties.length) params.specs = specialties.join(',');
    if (sortBy) params.sort = sortBy;
    navigate({ pathname, search: queryString.stringify(params) }, { replace: true });
  }, [searchText, consultType, specialties, sortBy, navigate, pathname]);

  return (
    <DoctorPage
      allDoctors={allDoctors}
      loading={loading}
      filters={{ searchText, consultType, specialties, sortBy }}
      setters={{ setSearchText, setConsultType, setSpecialties, setSortBy }}
    />
  );
}

export default App;
