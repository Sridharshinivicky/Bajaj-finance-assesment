import { useState, useEffect } from 'react';

export function useDoctors() {
  const [allDoctors, setAllDoctors] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('https://srijandubey.github.io/campus-api-mock/SRM-C1-25.json')
      .then(res => res.json())
      .then(data => {
        setAllDoctors(data.doctors || []);
        setLoading(false);
      });
  }, []);

  return { allDoctors, loading };
}
