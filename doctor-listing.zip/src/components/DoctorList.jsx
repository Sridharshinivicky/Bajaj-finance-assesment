import React from 'react';

export default function DoctorList({ allDoctors, filters }) {
  let list = [...allDoctors];

  if (filters.searchText) {
    list = list.filter(d =>
      d.name.toLowerCase().includes(filters.searchText.toLowerCase())
    );
  }
  if (filters.consultType) {
    list = list.filter(d => d.consultationType === filters.consultType);
  }
  if (filters.specialties.length) {
    list = list.filter(d =>
      filters.specialties.every(spec => d.specialities.includes(spec))
    );
  }
  if (filters.sortBy === 'fees') {
    list.sort((a, b) => a.fees - b.fees);
  } else if (filters.sortBy === 'experience') {
    list.sort((a, b) => b.experience - a.experience);
  }

  return (
    <div>
      {list.length > 0 ? (
        list.map(d => (
          <div key={d.id} data-testid="doctor-card">
            <h5 data-testid="doctor-name">{d.name}</h5>
            <p data-testid="doctor-specialty">{d.specialities.join(', ')}</p>
            <p data-testid="doctor-experience">{d.experience} yrs</p>
            <p data-testid="doctor-fee">₹{d.fees}</p>
          </div>
        ))
      ) : (
        <p>No doctors match your criteria.</p>
      )}
    </div>
  );
}
