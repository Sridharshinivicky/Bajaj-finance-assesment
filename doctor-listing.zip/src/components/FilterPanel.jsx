import React from 'react';

export default function FilterPanel({
  specialtiesList,
  consultType,
  setConsultType,
  specialties,
  setSpecialties,
  sortBy,
  setSortBy
}) {
  return (
    <aside>
      <h4 data-testid="filter-header-moc">Consultation Mode</h4>
      <label>
        <input
          type="radio"
          data-testid="filter-video-consult"
          value="Video Consult"
          checked={consultType === 'Video Consult'}
          onChange={() => setConsultType('Video Consult')}
        />
        Video Consult
      </label>
      <label>
        <input
          type="radio"
          data-testid="filter-in-clinic"
          value="In Clinic"
          checked={consultType === 'In Clinic'}
          onChange={() => setConsultType('In Clinic')}
        />
        In Clinic
      </label>

      <h4 data-testid="filter-header-speciality">Speciality</h4>
      {specialtiesList.map(spec => {
        const testId = `filter-specialty-${spec.replace(/\s+|\/+/, '-')}`;
        return (
          <label key={spec}>
            <input
              type="checkbox"
              data-testid={testId}
              value={spec}
              checked={specialties.includes(spec)}
              onChange={() =>
                setSpecialties(s =>
                  s.includes(spec) ? s.filter(x => x !== spec) : [...s, spec]
                )
              }
            />
            {spec}
          </label>
        );
      })}

      <h4 data-testid="filter-header-sort">Sort</h4>
      <select value={sortBy} onChange={e => setSortBy(e.target.value)}>
        <option value="">— none —</option>
        <option value="fees" data-testid="sort-fees">Fees (ascending)</option>
        <option value="experience" data-testid="sort-experience">Experience (descending)</option>
      </select>
    </aside>
  );
}
