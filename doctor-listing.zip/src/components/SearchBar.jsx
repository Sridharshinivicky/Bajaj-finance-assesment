import React, { useState, useEffect } from 'react';

export default function SearchBar({ allDoctors, searchText, setSearchText }) {
  const [suggestions, setSuggestions] = useState([]);

  useEffect(() => {
    if (!searchText) {
      setSuggestions([]);
      return;
    }
    const matches = allDoctors
      .filter(d => d.name.toLowerCase().includes(searchText.toLowerCase()))
      .slice(0, 3);
    setSuggestions(matches);
  }, [searchText, allDoctors]);

  const onSelect = (name) => {
    setSearchText(name);
    setSuggestions([]);
  };

  return (
    <div>
      <input
        data-testid="autocomplete-input"
        value={searchText}
        placeholder="Search doctors…"
        onChange={e => setSearchText(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && onSelect(searchText)}
      />
      {suggestions.length > 0 && (
        <ul>
          {suggestions.map(d => (
            <li
              key={d.id}
              data-testid="suggestion-item"
              onClick={() => onSelect(d.name)}
            >
              {d.name}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
