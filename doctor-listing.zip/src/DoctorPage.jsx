import React from 'react';
import SearchBar from './components/SearchBar';
import FilterPanel from './components/FilterPanel';
import DoctorList from './components/DoctorList';

export default function DoctorPage({ allDoctors, loading, filters, setters }) {
  if (loading) return <p>Loading…</p>;

  const specialtiesList = Array.from(
    new Set(allDoctors.flatMap(d => d.specialities))
  ).sort();

  return (
    <div>
      <SearchBar
        allDoctors={allDoctors}
        searchText={filters.searchText}
        setSearchText={setters.setSearchText}
      />

      <div style={{ display: 'flex' }}>
        <FilterPanel
          specialtiesList={specialtiesList}
          consultType={filters.consultType}
          setConsultType={setters.setConsultType}
          specialties={filters.specialties}
          setSpecialties={setters.setSpecialties}
          sortBy={filters.sortBy}
          setSortBy={setters.setSortBy}
        />
        <DoctorList allDoctors={allDoctors} filters={filters} />
      </div>
    </div>
  );
}
